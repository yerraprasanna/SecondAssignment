INSERT INTO product (product_name, price, description) VALUES ('Dress',800,'long top kurti');
INSERT INTO product (product_name, price, description) VALUES ('Bottle',50,'red color plastic bottle');
INSERT INTO product (product_name, price, description) VALUES ('Chair',1000,'brown color chair');